package com.capgemini.movieRatingService.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.movieRatingService.bean.Rating;
import com.capgemini.movieRatingService.bean.UserRating;

@RestController
@RequestMapping("/ratings")
public class MovieRatingController {

	@GetMapping("/{userID}")
	public UserRating getMovieRating(@PathVariable String userID)
	{
		
		if(userID.equals("xyz"))
		{
			List<Rating> ratings= Arrays.asList(new Rating(101, 2), new Rating(102, 3));
			UserRating userRating=new UserRating("xyz",ratings);
			return userRating;
		}
		return null;
	}
}
