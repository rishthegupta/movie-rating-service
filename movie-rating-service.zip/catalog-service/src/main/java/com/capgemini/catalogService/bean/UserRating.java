package com.capgemini.catalogService.bean;

import java.util.List;

public class UserRating {

	private String userID;
	private List<Rating> ratings;
	public UserRating() {
		super();
	}
	public UserRating(String userID, List<Rating> ratings) {
		super();
		this.userID = userID;
		this.ratings = ratings;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public List<Rating> getRatings() {
		return ratings;
	}
	public void setRatings(List<Rating> ratings) {
		this.ratings = ratings;
	}
}
