package com.capgemini.catalogService.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.capgemini.catalogService.bean.CatalogItem;
import com.capgemini.catalogService.bean.Movie;
import com.capgemini.catalogService.bean.MovieCatalog;
import com.capgemini.catalogService.bean.Rating;
import com.capgemini.catalogService.bean.UserRating;

@RestController
@RequestMapping("/catalog")
public class MovieCatalogController {
	
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	
	@GetMapping("/{userID}")
	public MovieCatalog getMovieCatalog(@PathVariable String userID)
	{
	
		// call the movie-rating-service and get the ratings details  
		UserRating ratings =restTemplate.getForObject("http://localhost:8091/ratings/"+userID, UserRating.class);
	
		List<Rating> movieRatings = ratings.getRatings();
		
		
		List<CatalogItem> catalogItems= new ArrayList<>();
		
		
		
		for(Rating movieRating:movieRatings)
		{
			Movie movie= restTemplate.getForObject("http://localhost:8090/movies/"+movieRating.getMovieID(), Movie.class);
			
			catalogItems.add(new CatalogItem(movie,movieRating.getRating()));
			
		
		}
		
		return new MovieCatalog(catalogItems);
		
	}

}
