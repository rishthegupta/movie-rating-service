package com.capgemini.catalogService.bean;

import java.util.List;

public class MovieCatalog {
	
	private List<CatalogItem> catelogItem;

	public MovieCatalog(List<CatalogItem> catelogItem) {
		super();
		this.catelogItem = catelogItem;
	}

	public MovieCatalog() {
		super();
	}

	public List<CatalogItem> getCatelogItem() {
		return catelogItem;
	}

	public void setCatelogItem(List<CatalogItem> catelogItem) {
		this.catelogItem = catelogItem;
	}
	
	

}
