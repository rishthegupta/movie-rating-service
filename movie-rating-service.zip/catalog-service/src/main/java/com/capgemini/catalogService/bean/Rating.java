package com.capgemini.catalogService.bean;

public class Rating {

	
	private int movieID;
	private int rating;
	public int getMovieID() {
		return movieID;
	}
	public void setMovieID(int movieID) {
		this.movieID = movieID;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public Rating(int movieID, int rating) {
		super();
		this.movieID = movieID;
		this.rating = rating;
	}
	public Rating() {
		super();
	}
	
	
	
	
}
