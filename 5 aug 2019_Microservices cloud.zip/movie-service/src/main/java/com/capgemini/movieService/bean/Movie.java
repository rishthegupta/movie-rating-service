package com.capgemini.movieService.bean;

import java.util.List;

public class Movie {
	
	
	
	private int movieID;
	private String movieTitle;
	private int releaseYear;
	private List<String> casts;
	
	
	public List<String> getCasts() {
		return casts;
	}
	public void setCasts(List<String> casts) {
		this.casts = casts;
	}
	public int getMovieID() {
		return movieID;
	}
	public void setMovieID(int movieID) {
		this.movieID = movieID;
	}
	public String getMovieTitle() {
		return movieTitle;
	}
	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}
	public int getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(int releaseYear) {
		this.releaseYear = releaseYear;
	}
	
	public Movie(int movieID, String movieTitle, int releaseYear, List<String> casts) {
		super();
		this.movieID = movieID;
		this.movieTitle = movieTitle;
		this.releaseYear = releaseYear;
		this.casts = casts;
	}
	public Movie() {
		super();
	}


}
